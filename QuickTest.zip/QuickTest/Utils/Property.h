#ifndef PROPERTY_H
#define PROPERTY_H

#define PROPERTY(QType, name) \
    Q_PROPERTY(QType name READ name WRITE set##name NOTIFY name##Changed) \
    public: \
    QType name(){return m_##name;}\
    void set##name(QType value){m_##name = value; emit name##Changed();} \
    Q_SIGNAL void name##Changed(); \
    private: \
    QType m_##name;

#endif // PROPERTY_H
