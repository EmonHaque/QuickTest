#include <QGuiApplication>
#include <QSurfaceFormat>
#include <QQmlContext>
#include <QQmlApplicationEngine>
#include "ViewModel/avm.h"
#include "ViewModel/bvm.h"
#include "ViewModel/cvm.h"
#include "ViewModel/mainvm.h"

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);

    QSurfaceFormat format;
    format.setSamples(15);
    QSurfaceFormat::setDefaultFormat(format);

    QQmlApplicationEngine engine;

    engine.rootContext()->setContextProperty("aContext", new AVM());
    engine.rootContext()->setContextProperty("bContext", new BVM());
    engine.rootContext()->setContextProperty("cContext", new CVM());
    engine.rootContext()->setContextProperty("mainContext", new MainVM());

    engine.load("qrc:/main.qml");
    return app.exec();
}
