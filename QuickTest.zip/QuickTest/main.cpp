#include <QGuiApplication>
#include <QSurfaceFormat>
#include <QQmlContext>
#include <QQmlApplicationEngine>
#include "ViewModel/AddVM.h"
#include "ViewModel/EditVM.h"
#include "ViewModel/TransactVM.h"
#include "ViewModel/ReportVM.h"
#include "ViewModel/MainVM.h"

MainVM *mvm;

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);

    QSurfaceFormat format;
    format.setSamples(15);
    QSurfaceFormat::setDefaultFormat(format);

    QQmlApplicationEngine engine;
    mvm = new MainVM();
    engine.rootContext()->setContextProperty("addContext", new AddVM());
    engine.rootContext()->setContextProperty("editContext", new EditVM());
    engine.rootContext()->setContextProperty("transactContext", new TransactVM());
    engine.rootContext()->setContextProperty("reportContext", new ReportVM());
    engine.rootContext()->setContextProperty("mainContext", mvm);

    engine.load("qrc:/main.qml");
    return app.exec();
}
