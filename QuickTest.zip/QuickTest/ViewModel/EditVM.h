#ifndef EDITVM_H
#define EDITVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>

class EditVM : public QObject
{
    Q_OBJECT
    PROPERTY(QVector<View*>, views)
public:
    explicit EditVM(QObject *parent = nullptr);

signals:

};

#endif // EDITVM_H
