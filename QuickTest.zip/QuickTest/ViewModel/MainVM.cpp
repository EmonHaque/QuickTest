#include "MainVM.h"

MainVM::MainVM(QObject *parent) : QObject(parent)
{
    m_views.push_back(new View(HomeIcon, "Views/HomeView.qml"));
    m_views.push_back(new View(AddIcon, "Views/AddView.qml"));
    m_views.push_back(new View(EditIcon, "Views/EditView.qml"));
    m_views.push_back(new View(TransactIcon, "Views/TransactView.qml"));
    m_views.push_back(new View(ReportIcon, "Views/ReportView.qml"));
    emit viewsChanged();

    db = QSqlDatabase::addDatabase("QSQLITE");
    if(!QFileInfo::exists(DatabaseName)){
        db.setDatabaseName(DatabaseName);
        createDatabase();
    }
    else{
        db.setDatabaseName(DatabaseName);
        fillVectors();
    }
}

void MainVM::createDatabase()
{
    QFile file(SQLScript);
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    auto script = file.readAll();
    file.close();

    auto statements = script.split(';');
    QSqlQuery query(db);
    db.open();
    foreach(auto statement, statements) query.exec(statement);
    db.close();
}

void MainVM::fillVectors()
{
    QList<QString> list;
    list.append("SELECT * FROM Plots ORDER BY Name");
    list.append("SELECT * FROM Spaces ORDER BY PlotId, Name");
    list.append("SELECT * FROM ControlHeads ORDER BY Name");
    list.append("SELECT * FROM Heads ORDER BY ControlId, Name");
    list.append("SELECT * FROM Tenants ORDER BY Name");
    list.append("SELECT * FROM Leases WHERE IsExpired = 0 ORDER BY PlotId, SpaceId");
    list.append("SELECT * FROM Receivables");
    list.append("SELECT MAX(Id) FROM Leases");
    QSqlQuery query;
    db.open();

    for(int i = 0; i < list.size(); i++){
        query.exec(list.at(i));
        switch (i) {
        case 0:
            while (query.next()) {
                auto plot = new Plot();
                plot->setid(query.value(0).toInt());
                plot->setname(query.value(1).toString());
                plot->setdescription(query.value(2).toString());
                m_plots.push_back(plot);
            }
            emit plotsChanged();
            break;
        case 1:
            while (query.next()) {
                auto space = new Space();
                space->setid(query.value(0).toInt());
                space->setplotId(query.value(1).toInt());
                space->setname(query.value(2).toString());
                space->setdescription(query.value(3).toString());
                space->setisVacant(query.value(4).toBool());
                m_spaces.push_back(space);
            }
            emit spacesChanged();
            break;
        case 2:
            while (query.next()) {
                auto control = new ControlHead();
                control->setid(query.value(0).toInt());
                control->setname(query.value(1).toString());
                m_controlHeads.push_back(control);
            }
            emit controlHeadsChanged();
            break;
        case 3:
            while (query.next()) {
                auto head = new Head();
                head->setid(query.value(0).toInt());
                head->setcontrolId(query.value(1).toInt());
                head->setname(query.value(2).toString());
                head->setdescription(query.value(3).toString());
                m_heads.push_back(head);
            }
            emit headsChanged();
            break;
        case 4:
            while (query.next()) {
                auto tenant = new Tenant();
                tenant->setid(query.value(0).toInt());
                tenant->setname(query.value(1).toString());
                tenant->setfather(query.value(2).toString());
                auto mother = query.value(3).isNull() ? nullptr : query.value(3).toString();
                auto husband = query.value(4).isNull() ? nullptr : query.value(4).toString();
                tenant->setmother(mother);
                tenant->sethusband(husband);
                tenant->setaddress(query.value(5).toString());
                auto nid = query.value(6).isNull() ? nullptr : query.value(6).toString();
                tenant->setnid(nid);
                tenant->setcontactNo(query.value(7).toString());
                tenant->sethasLeft(query.value(8).toBool());
                m_tenants.push_back(tenant);
            }
            emit tenantsChanged();
            break;
        case 5:
            while (query.next()) {
                auto lease = new Lease();
                lease->setid(query.value(0).toInt());
                lease->setplotId(query.value(1).toInt());
                lease->setspaceId(query.value(2).toInt());
                lease->settenantId(query.value(3).toInt());
                lease->setdate(query.value(4).toDate());
                lease->setbusiness(query.value(5).toString());
                lease->setisExpired(query.value(6).toBool());
                m_leases.push_back(lease);
            }
            emit leasesChanged();
            break;
        case 6:
            while (query.next()) {
                auto receivable = new Receivable();
                receivable->setleaseId(query.value(0).toInt());
                receivable->setheadId(query.value(1).toInt());
                receivable->setamount(query.value(2).toInt());
                m_receivables.push_back(receivable);
            }
            emit receivablesChanged();
            break;
        case 7:
            query.exec();
            query.first();
            maxLeaseId = query.value(0).toInt();
            break;
        }
    }
    db.close();
}
