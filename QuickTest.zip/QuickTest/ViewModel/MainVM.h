#ifndef MAINVM_H
#define MAINVM_H

#include <QObject>
#include <QVector>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QFile>
#include <QFileInfo>
#include <QtDebug>
#include <QVariant>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>
#include <Model/Plot.h>
#include <Model/Space.h>
#include <Model/Tenant.h>
#include <Model/ControlHead.h>
#include <Model/Head.h>
#include <Model/Lease.h>
#include <Model/Receivable.h>

class MainVM : public QObject
{
    Q_OBJECT
    PROPERTY(QVector<View*>, views)
    PROPERTY(QVector<Plot*>, plots)
    PROPERTY(QVector<Space*>, spaces)
    PROPERTY(QVector<Tenant*>, tenants)
    PROPERTY(QVector<ControlHead*>, controlHeads)
    PROPERTY(QVector<Head*>, heads)
    PROPERTY(QVector<Lease*>, leases)
    PROPERTY(QVector<Receivable*>, receivables)
public:
    explicit MainVM(QObject *parent = nullptr);
    QSqlDatabase db;
    int maxLeaseId;

private:
    void createDatabase();
    void fillVectors();

};

#endif // MAINVM_H
