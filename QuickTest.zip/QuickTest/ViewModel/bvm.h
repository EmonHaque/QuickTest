#ifndef BVM_H
#define BVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>

class BVM : public QObject
{
    Q_OBJECT
    PROPERTY(QVector<View*>, views)
public:
    explicit BVM(QObject *parent = nullptr);

signals:

};

#endif // BVM_H
