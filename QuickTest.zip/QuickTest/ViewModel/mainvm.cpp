#include "mainvm.h"

MainVM::MainVM(QObject *parent) : QObject(parent)
{
    m_views.push_back(new View(AIcon, "Views/a.qml"));
    m_views.push_back(new View(BIcon, "Views/b.qml"));
    m_views.push_back(new View(CIcon, "Views/c.qml"));
    emit viewsChanged();
}
