#ifndef MAINVM_H
#define MAINVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>

class MainVM : public QObject
{
    Q_OBJECT
    PROPERTY(QVector<View*>, views)
    PROPERTY(QString, minimizeIcon)
    PROPERTY(QString, maximizeIcon)
    PROPERTY(QString, restoreIcon)
    PROPERTY(QString, closeIcon)
public:
    explicit MainVM(QObject *parent = nullptr);

signals:

};

#endif // MAINVM_H
