#ifndef CVM_H
#define CVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>

class CVM : public QObject
{
    Q_OBJECT
    PROPERTY(QVector<View*>, views)
public:
    explicit CVM(QObject *parent = nullptr);

signals:

};

#endif // CVM_H
