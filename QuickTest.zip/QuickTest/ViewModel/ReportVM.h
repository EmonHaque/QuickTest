#ifndef REPORTVM_H
#define REPORTVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>

class ReportVM : public QObject
{
    Q_OBJECT
    PROPERTY(QVector<View*>, views)
public:
    explicit ReportVM(QObject *parent = nullptr);

signals:

};

#endif // REPORTVM_H
