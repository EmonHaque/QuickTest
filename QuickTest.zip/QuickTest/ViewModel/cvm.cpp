#include "cvm.h"

CVM::CVM(QObject *parent) : QObject(parent)
{
    m_views.push_back(new View(JIcon, "Views/CViews/j.qml"));
    m_views.push_back(new View(KIcon, "Views/CViews/k.qml"));
    m_views.push_back(new View(LIcon, "Views/CViews/l.qml"));
    emit viewsChanged();
}
