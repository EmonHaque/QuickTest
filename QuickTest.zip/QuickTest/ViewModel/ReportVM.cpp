#include "ReportVM.h"

ReportVM::ReportVM(QObject *parent) : QObject(parent)
{
    m_views.push_back(new View(PlotIcon, "Views/ReportViews/PlotView.qml"));
    m_views.push_back(new View(SpaceIcon, "Views/ReportViews/SpaceView.qml"));
    m_views.push_back(new View(TenantIcon, "Views/ReportViews/TenantView.qml"));
}
