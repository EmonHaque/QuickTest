#ifndef ADDVM_H
#define ADDVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>
#include <Model/ComboModel.h>
#include <Model/Plot.h>

class AddVM : public QObject
{
    Q_OBJECT
    PROPERTY(QVector<ComboModel*>, comboModel)
    PROPERTY(Plot*, newPlot)
public:
    explicit AddVM(QObject *parent = nullptr);

signals:

};

#endif // ADDVM_H
