#include "AddVM.h"

AddVM::AddVM(QObject *parent) : QObject(parent)
{
    for(int i = 0; i < 10; i++)
        m_comboModel.push_back(new ComboModel("Name " + QString::number(i + 1), i + 10));
    emit comboModelChanged();
    setnewPlot(new Plot());

}
