#ifndef TRANSACTVM_H
#define TRANSACTVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>

class TransactVM : public QObject
{
    Q_OBJECT
public:
    explicit TransactVM(QObject *parent = nullptr);

signals:

};

#endif // TRANSACTVM_H
