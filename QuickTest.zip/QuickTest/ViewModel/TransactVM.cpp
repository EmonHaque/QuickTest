#include "TransactVM.h"

TransactVM::TransactVM(QObject *parent) : QObject(parent)
{

}
