#include "bvm.h"

BVM::BVM(QObject *parent) : QObject(parent)
{
    m_views.push_back(new View(GIcon, "Views/BViews/h.qml"));
    m_views.push_back(new View(HIcon, "Views/BViews/h.qml"));
    m_views.push_back(new View(IIcon, "Views/BViews/i.qml"));
    emit viewsChanged();
}
