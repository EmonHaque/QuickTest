#ifndef AVM_H
#define AVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>

class AVM : public QObject
{
    Q_OBJECT
    PROPERTY(QVector<View*>, views)
public:
    explicit AVM(QObject *parent = nullptr);

signals:

};

#endif // AVM_H
