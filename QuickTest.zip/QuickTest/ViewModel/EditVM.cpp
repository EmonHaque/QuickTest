#include "EditVM.h"

EditVM::EditVM(QObject *parent) : QObject(parent)
{  
    m_views.push_back(new View(PlotIcon, "Views/EditViews/PlotView.qml"));
    m_views.push_back(new View(SpaceIcon, "Views/EditViews/SpaceView.qml"));
    m_views.push_back(new View(TenantIcon, "Views/EditViews/TenantView.qml"));
    m_views.push_back(new View(LeaseIcon, "Views/EditViews/LeaseView.qml"));
    m_views.push_back(new View(HeadIcon, "Views/EditViews/HeadView.qml"));

    emit viewsChanged();
}
