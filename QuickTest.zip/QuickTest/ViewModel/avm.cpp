#include "avm.h"

AVM::AVM(QObject *parent) : QObject(parent)
{
    m_views.push_back(new View(DIcon, "Views/AViews/d.qml"));
    m_views.push_back(new View(EIcon, "Views/AViews/e.qml"));
    m_views.push_back(new View(FIcon, "Views/AViews/f.qml"));
    emit viewsChanged();
}
