#ifndef VIEW_H
#define VIEW_H

#include <QObject>
#include "Utils/Property.h"

class View : public QObject{
    Q_OBJECT
    PROPERTY(QString, icon)
    PROPERTY(QString, view)

public:
        View(QString icon, QString view): m_icon(icon), m_view(view) {}
};

#endif // VIEW_H
