#ifndef PLOT_H
#define PLOT_H

#include <QObject>
#include <Utils/Property.h>

class Plot : public QObject{
    Q_OBJECT
    PROPERTY(int, id)
    PROPERTY(QString, name)
    PROPERTY(QString, description)
};

#endif // PLOT_H
