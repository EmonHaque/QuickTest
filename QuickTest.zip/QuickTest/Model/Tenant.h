#ifndef TENANT_H
#define TENANT_H

#include <QObject>
#include <Utils/Property.h>

class Tenant : public QObject{
    Q_OBJECT
    PROPERTY(int, id)
    PROPERTY(QString, name)
    PROPERTY(QString, father)
    PROPERTY(QString, mother)
    PROPERTY(QString, husband)
    PROPERTY(QString, address)
    PROPERTY(QString, nid)
    PROPERTY(QString, contactNo)
    PROPERTY(bool, hasLeft)
};

#endif // TENANT_H
