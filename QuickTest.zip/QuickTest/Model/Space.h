#ifndef SPACE_H
#define SPACE_H

#include <QObject>
#include <Utils/Property.h>

class Space : public QObject{
    Q_OBJECT
    PROPERTY(int, id)
    PROPERTY(int, plotId)
    PROPERTY(QString, name)
    PROPERTY(QString, description)
    PROPERTY(bool, isVacant)
};

#endif // SPACE_H
