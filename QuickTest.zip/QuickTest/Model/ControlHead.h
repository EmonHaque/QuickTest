#ifndef CONTROLHEAD_H
#define CONTROLHEAD_H

#include <QObject>
#include <Utils/Property.h>

class ControlHead : public QObject{
    Q_OBJECT
    PROPERTY(int, id)
    PROPERTY(QString, name)
};

#endif // CONTROLHEAD_H
