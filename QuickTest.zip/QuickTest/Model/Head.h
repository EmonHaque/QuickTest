#ifndef HEAD_H
#define HEAD_H

#include <QObject>
#include <Utils/Property.h>

class Head : public QObject{
    Q_OBJECT
    PROPERTY(int, id)
    PROPERTY(int, controlId)
    PROPERTY(QString, name)
    PROPERTY(QString, description)
};

#endif // HEAD_H
