#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <QObject>
#include <Utils/Property.h>

class Transaction : public QObject{
    Q_OBJECT
    PROPERTY(QString, name)
    PROPERTY(QString, description)
};

#endif // TRANSACTION_H
