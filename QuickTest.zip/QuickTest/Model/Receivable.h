#ifndef RECEIVABLE_H
#define RECEIVABLE_H

#include <QObject>
#include <Utils/Property.h>

class Receivable : public QObject{
    Q_OBJECT
    PROPERTY(int, leaseId)
    PROPERTY(int, headId)
    PROPERTY(int, amount)
};

#endif // RECEIVABLE_H
