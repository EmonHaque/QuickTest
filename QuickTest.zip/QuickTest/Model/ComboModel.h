#ifndef COMBOMODEL_H
#define COMBOMODEL_H

#include <QObject>
#include <QString>
#include "Utils/Property.h"

class ComboModel : public QObject{
    Q_OBJECT
    PROPERTY(QString, name)
    PROPERTY(int, age)

    public:
        ComboModel(QString name, int age): m_name(name), m_age(age) {}
};

#endif // COMBOMODEL_H
