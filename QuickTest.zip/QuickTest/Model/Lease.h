#ifndef LEASE_H
#define LEASE_H

#include <QObject>
#include <QDate>
#include <Utils/Property.h>

class Lease : public QObject{
    Q_OBJECT
    PROPERTY(int, id)
    PROPERTY(int, plotId)
    PROPERTY(int, spaceId)
    PROPERTY(int, tenantId)
    PROPERTY(QDate, date)
    PROPERTY(QString, business)
    PROPERTY(bool, isExpired)
};

#endif // LEASE_H
