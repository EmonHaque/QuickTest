#include "LedgerVM.h"

LedgerVM::LedgerVM(QObject *parent) : QObject(parent)
{
    m_views.push_back(new View(PlotIcon, "Views/LedgerViews/PlotView.qml", SubViewType::Plot));
    m_views.push_back(new View(SpaceIcon, "Views/LedgerViews/SpaceView.qml", SubViewType::Space));
    m_views.push_back(new View(TenantIcon, "Views/LedgerViews/TenantView.qml", SubViewType::Tenant));
    emit viewsChanged();
}
