#ifndef MAINVM_H
#define MAINVM_H

#include <QObject>
#include <QtCore>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>
#include <Model/Plot.h>
#include <Model/Space.h>
#include <Model/Tenant.h>
#include <Model/ControlHead.h>
#include <Model/Head.h>
#include <Model/Lease.h>
#include <Model/Receivable.h>

class MainVM : public QObject
{
    Q_OBJECT
    Property(QVector<View*>, views)
    Property(QVector<Plot*>, plots);
    Property(QVector<Space*>, spaces);
    Property(QVector<Tenant*>, tenants);
    Property(QVector<ControlHead*>, controlHeads);
    Property(QVector<Head*>, heads);
    Property(QVector<Lease*>, leases);

    Property(QVector<Space*>, filteredSpaces);
    Property(QVector<Head*>, receivableHeads);
    Property(QVector<Head*>, filteredHeads);
    Property(QVector<Lease*>, filteredLeases);

    Property(int, selectedPlot);
    Property(int, selectedSpace);
    Property(int, selectedTenant);
    Property(int, selectedControlHead);
    Property(int, selectedHead);
    Property(int, selectedReceivableHead)
    Property(int, selectedLease);

    Property(ViewType::Type, selectedView)
    Property(SubViewType::Type, selectedSubView)

public:
    explicit MainVM(QObject *parent = nullptr);
    QSqlDatabase db;
    int maxPlotId, maxSpaceId, maxTenantId, maxHeadId, maxLeaseId;


private:
    void createDatabase();
    void fillVectors();
    void setMaxIds();
    template<class T> int getMaxId(QVector<T> &vec);
    void setSelected();
    void hookupSignalAndSlots();

private slots:
    void onSelectedPlotChanged();
    void onSelectedControlHeadChanged();
};

#endif // MAINVM_H
