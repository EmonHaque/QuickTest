#ifndef AVM_H
#define AVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>
#include <Model/Plot.h>
#include <Model/Space.h>
#include <Model/Tenant.h>
#include <Model/Head.h>
#include <Model/Lease.h>
#include <Model/Receivable.h>
#include "MainVM.h"

extern MainVM *mvm;

class AddVM : public QObject
{
    Q_OBJECT
    Property(Plot*, newPlot)
    Property(Space*, newSpace)
    Property(Tenant*, newTenant)
    Property(Head*, newHead)
    Property(Lease*, newLease)
    Property(Receivable*, newReceivable)

    Property(QVector<Space*>, vacantSpaces)
    Property(QVector<Tenant*>, availableTenants)
    Property(bool, isNewPlotValid)

public:
    explicit AddVM(QObject *parent = nullptr);
    Q_INVOKABLE void addNewPlot();
    Q_INVOKABLE void addNewSpace();
    Q_INVOKABLE void addNewTenant();
    Q_INVOKABLE void addNewHead();
    Q_INVOKABLE void addNewLease();
    Q_INVOKABLE void addReceivable();
    Q_INVOKABLE void removeReceivable(int index);
    Q_INVOKABLE QString getHeadName(int headId);

private slots:
    void onSelectedPlotChanged();
    void onNewPlotChanged();
    void validateNewPlot();

private:
    void hookupSignalsAndSlots();
    void setNews();

};

#endif // AVM_H
