#include "AddVM.h"

AddVM::AddVM(QObject *parent) : QObject(parent)
{
    foreach(auto space, mvm->filteredSpaces()){
        if(space->isVacant())
            m_vacantSpaces.push_back(space);
    }
    emit vacantSpacesChanged();

    foreach(auto tenant, mvm->tenants()){
        if(!tenant->hasLeft())
            m_availableTenants.push_back(tenant);
    }
    emit availableTenantsChanged();

    mvm->setselectedSpace(0);

    hookupSignalsAndSlots();
    setNews();
}

void AddVM::addNewPlot()
{
    newPlot()->setid(++mvm->maxPlotId);
    mvm->db.open();

    QSqlQuery query;
    query.prepare("INSERT INTO Plots (Name, Description) VALUES(:Name, :Description)");
    query.bindValue(":Name", newPlot()->name());
    query.bindValue(":Description", newPlot()->description());
    if(query.exec()){
        int index = mvm->plots().size();
        mvm->plots().push_back(newPlot());
        newPlot()->disconnect(this);
        emit mvm->plotsChanged();
        mvm->setselectedPlot(index);
        setnewPlot(new Plot());
    }
    mvm->db.close();
}

void AddVM::addNewSpace()
{
    newSpace()->setid(++mvm->maxSpaceId);
    newSpace()->setplotId(mvm->plots()[mvm->selectedPlot()]->id());
    mvm->db.open();

    QSqlQuery query;
    query.prepare("INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(:PlotId, :Name, :Description, 1)");
    query.bindValue(":PlotId", newSpace()->plotId());
    query.bindValue(":Name", newSpace()->name());
    query.bindValue(":Description", newSpace()->description());

    if(query.exec()){
        int index = m_vacantSpaces.size();
        mvm->spaces().push_back(newSpace());
        mvm->filteredSpaces().push_back(newSpace());
        m_vacantSpaces.push_back(newSpace());

        emit mvm->spacesChanged();
        emit mvm->filteredSpacesChanged();
        emit vacantSpacesChanged();
        mvm->setselectedSpace(index);

        setnewSpace(new Space());
    }


    mvm->db.close();
}

void AddVM::addNewTenant()
{
    newTenant()->setid(++mvm->maxTenantId);
    mvm->db.open();

    QSqlQuery query;
    query.prepare("INSERT INTO Tenants (Name, Father, Mother, Husband, Address, NID, ContactNo, HasLeft)"
                  "VALUES(:Name, :Father, :Mother, :Husband, :Address, :NID, :ContactNo, 0)");
    query.bindValue(":Name", newTenant()->name());
    query.bindValue(":Father", newTenant()->father());
    query.bindValue(":Mother", newTenant()->mother());
    query.bindValue(":Husband", newTenant()->husband());
    query.bindValue(":Address", newTenant()->address());
    query.bindValue(":NID", newTenant()->nid());
    query.bindValue(":ContactNo", newTenant()->contactNo());

    if(query.exec()){
        int index = m_availableTenants.size();
        mvm->tenants().push_back(newTenant());
        m_availableTenants.push_back(newTenant());
        emit mvm->tenantsChanged();
        emit availableTenantsChanged();
        mvm->setselectedTenant(index);
        setnewTenant(new Tenant());
    }
    mvm->db.close();
}

void AddVM::addNewHead()
{
    newHead()->setid(++mvm->maxHeadId);
    newHead()->setcontrolId(mvm->controlHeads()[mvm->selectedControlHead()]->id());

    mvm->db.open();
    QSqlQuery query;
    query.prepare("INSERT INTO Heads (ControlId, Name, Description) VALUES(:ControlId, :Name, :Description)");
    query.bindValue(":ControlId", newHead()->controlId());
    query.bindValue(":Name", newHead()->name());
    query.bindValue(":Description", newHead()->description());

    if(query.exec()){
        int index = mvm->filteredHeads().size();
        mvm->filteredHeads().push_back(newHead());
        mvm->heads().push_back(newHead());
        emit mvm->headsChanged();
        emit mvm->filteredHeadsChanged();

        if(newHead()->controlId() == 1){
            int receivableIndex = mvm->receivableHeads().size();
            mvm->receivableHeads().push_back(newHead());
            emit mvm->receivableHeadsChanged();
            mvm->setselectedReceivableHead(receivableIndex);
        }
        setnewHead(new Head());
        mvm->setselectedHead(index);
    }
    else qDebug()<< query.lastError();
    mvm->db.close();
}

void AddVM::addNewLease()
{
    newLease()->settenantId(m_availableTenants[mvm->selectedTenant()]->id());
    newLease()->setplotId(m_vacantSpaces[mvm->selectedSpace()]->plotId());
    newLease()->setspaceId(m_vacantSpaces[mvm->selectedSpace()]->id());

    QVector<QSqlQuery> commands;
    mvm->db.open();
    QSqlQuery query1;
    query1.prepare("INSERT INTO Leases(PlotId, SpaceId, TenantId, Date, Business, IsExpired) VALUES(:PlotId, :SpaceId, :TenantId, :Date, :Business, 0)");
    query1.bindValue(":PlotId", newLease()->plotId());
    query1.bindValue(":SpaceId", newLease()->spaceId());
    query1.bindValue(":TenantId", newLease()->tenantId());
    query1.bindValue(":Date", newLease()->date());
    query1.bindValue(":Business", newLease()->business());

    QSqlQuery query2;
    query2.prepare("UPDATE Spaces SET IsVacant = 0 WHERE ID = :Id");
    query2.bindValue(":Id", newLease()->spaceId());
    commands.push_back(query1);
    commands.push_back(query2);

    foreach(auto receivable, newLease()->receivables()){
        QSqlQuery query3;
        query3.prepare("INSERT INTO Receivables(LeaseId, HeadId, Amount) VALUES(:LeaseId, :HeadId, :Amount)");
        query3.bindValue(":LeaseId", receivable->leaseId());
        query3.bindValue(":HeadId", receivable->headId());
        query3.bindValue(":Amount", receivable->amount());
        commands.push_back(query3);
    }
    qDebug() << commands.size() << " queries";
    int count = 0;
    QSqlDatabase::database().transaction();
    foreach(auto command, commands){
        qDebug() << "executing " << ++count;
        if(command.exec()) continue;
        else{
            qDebug()<< command.lastError();
            QSqlDatabase::database().rollback();
            mvm->db.close();
            return;
        }
    }
    QSqlDatabase::database().commit();
    mvm->db.close();

    for(int i =0; i < vacantSpaces().size(); i++){
        if(vacantSpaces()[i]->id() == newLease()->spaceId()){
            vacantSpaces()[i]->setisVacant(false);
            vacantSpaces().removeAt(i);
            emit vacantSpacesChanged();
            break;
        }
    }

    mvm->leases().push_back(newLease());
    mvm->filteredLeases().push_back(newLease());
    emit mvm->filteredLeasesChanged();

    setnewLease(new Lease());
    newLease()->setid(++mvm->maxLeaseId);
    newLease()->setdate(QDate::currentDate());
}

void AddVM::addReceivable()
{
    newReceivable()->setleaseId(newLease()->id());
    newReceivable()->setheadId(mvm->receivableHeads()[mvm->selectedReceivableHead()]->id());
    newLease()->receivables().push_back(newReceivable());
    emit newLease()->receivablesChanged();

    setnewReceivable(new Receivable());
}

void AddVM::removeReceivable(int index)
{
    delete newLease()->receivables().takeAt(index);
    emit newLease()->receivablesChanged();
}

QString AddVM::getHeadName(int headId)
{
    foreach(auto head, mvm->receivableHeads()){
        if(head->id() == headId)
            return head->name();
    }
}

void AddVM::onSelectedPlotChanged()
{
    if(mvm->plots().size() > 0){
        int plotId = mvm->plots()[mvm->selectedPlot()]->id();
        m_vacantSpaces.clear();
        for(int i= 0; i < mvm->filteredSpaces().size(); i++){
            if(mvm->filteredSpaces()[i]->plotId() == plotId)
                m_vacantSpaces.push_back(mvm->filteredSpaces()[i]);
        }
        emit vacantSpacesChanged();
        mvm->setselectedSpace(0);
    }
}

void AddVM::onNewPlotChanged()
{ 
    QObject::connect(newPlot(), &Plot::nameChanged, this, &AddVM::validateNewPlot);
    QObject::connect(newPlot(), &Plot::descriptionChanged, this, &AddVM::validateNewPlot);
    setisNewPlotValid(false);
}

void AddVM::validateNewPlot()
{
    bool hasMatchingName = false;
    foreach(auto plot, mvm->plots()){
        if(plot->name() == newPlot()->name())
            hasMatchingName = true;
    }
    if(!newPlot()->name().isEmpty() && !newPlot()->description().isEmpty() && !hasMatchingName)
        setisNewPlotValid(true);
    else setisNewPlotValid(false);
}

void AddVM::hookupSignalsAndSlots()
{
    QObject::connect(mvm, &MainVM::selectedPlotChanged, this, &AddVM::onSelectedPlotChanged);
    QObject::connect(this, &AddVM::newPlotChanged, this, &AddVM::onNewPlotChanged);
}

void AddVM::setNews()
{
    setnewPlot(new Plot());
    setnewSpace(new Space());
    setnewTenant(new Tenant());
    setnewHead(new Head());
    setnewReceivable(new Receivable());
    setnewLease(new Lease());
    newLease()->setid(++mvm->maxLeaseId);
    newLease()->setdate(QDate::currentDate());
}
