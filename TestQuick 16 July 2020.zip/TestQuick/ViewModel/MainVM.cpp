#include "MainVM.h"

MainVM::MainVM(QObject *parent) : QObject(parent)
{
    m_selectedPlot = m_selectedSpace = m_selectedTenant = m_selectedHead = m_selectedLease = m_selectedControlHead = m_selectedReceivableHead = -1;
    m_views.push_back(new View(HomeIcon, "Views/HomeView.qml", ViewType::Home));
    m_views.push_back(new View(AddIcon, "Views/AddView.qml", ViewType::Add));
    m_views.push_back(new View(EditIcon, "Views/EditView.qml", ViewType::Edit));
    m_views.push_back(new View(TransactIcon, "Views/TransactView.qml", ViewType::Transact));
    m_views.push_back(new View(LedgerIcon, "Views/LedgerView.qml", ViewType::Ledger));
    emit viewsChanged();

    db = QSqlDatabase::addDatabase("QSQLITE");
    if(QFileInfo::exists(Database)){
        db.setDatabaseName(Database);
        fillVectors();
    }
    else{
        db.setDatabaseName(Database);
        createDatabase();
    }
    foreach(auto head, m_heads){
        if(head->controlId() == 1)
            m_receivableHeads.push_back(head);
    }
    emit receivableHeadsChanged();
    setMaxIds();
    hookupSignalAndSlots();
    setSelected();
}

void MainVM::createDatabase()
{
    QFile file(":/init.sql");
    file.open(QIODevice::ReadOnly);
    auto script = file.readAll();
    file.close();

    auto statements = script.split(';');
    QSqlQuery query(db);
    db.open();
    foreach(auto statement, statements) query.exec(statement);
    db.close();

}

void MainVM::fillVectors()
{
    QFile file(":/startupQuery.sql");
    file.open(QIODevice::ReadOnly);
    auto script = file.readAll();
    auto statements = script.split(';');
    file.close();

    QVector<Receivable*> receivables;
    QSqlQuery query;
    db.open();

    for(int i=0; i < statements.size(); i++){
        query.exec(statements[i]);

        switch (i) {
        case 0:
            while (query.next()) {
                auto x = new Plot();
                x->setid(query.value(0).toInt());
                x->setname(query.value(1).toString());
                x->setdescription(query.value(2).toString());
                m_plots.push_back(x);
            }
            emit plotsChanged();
            break;
        case 1:
            while (query.next()) {
                auto x = new Space();
                x->setid(query.value(0).toInt());
                x->setplotId(query.value(1).toInt());
                x->setname(query.value(2).toString());
                x->setdescription(query.value(3).toString());
                x->setisVacant(query.value(4).toBool());
                m_spaces.push_back(x);
            }
            emit spacesChanged();
            break;
        case 2:
            while (query.next()) {
                auto x = new ControlHead();
                x->setid(query.value(0).toInt());
                x->setname(query.value(1).toString());
                m_controlHeads.push_back(x);
            }
            emit controlHeadsChanged();
            break;
        case 3:
            while (query.next()) {
                auto x = new Head();
                x->setid(query.value(0).toInt());
                x->setcontrolId(query.value(1).toInt());
                x->setname(query.value(2).toString());
                x->setdescription(query.value(3).toString());
                m_heads.push_back(x);
            }
            emit headsChanged();
            break;
        case 4:
            while (query.next()) {
                auto x = new Tenant();
                x->setid(query.value(0).toInt());
                x->setname(query.value(1).toString());
                x->setfather(query.value(2).toString());
                x->setmother(query.value(3).isNull() ? nullptr : query.value(3).toString());
                x->sethusband(query.value(4).isNull() ? nullptr : query.value(4).toString());
                x->setaddress(query.value(5).toString());
                x->sethusband(query.value(6).isNull() ? nullptr : query.value(6).toString());
                x->setcontactNo(query.value(7).toString());
                x->sethasLeft(query.value(8).toBool());
                m_tenants.push_back(x);
            }
            emit tenantsChanged();
            break;
        case 5:
            while (query.next()) {
                auto x = new Lease();
                x->setid(query.value(0).toInt());
                x->setplotId(query.value(1).toInt());
                x->setspaceId(query.value(2).toInt());
                x->settenantId(query.value(3).toInt());
                x->setdate(query.value(4).toDate());
                x->setbusiness(query.value(5).toString());
                x->setisExpired(query.value(6).toBool());
                m_leases.push_back(x);
            }
            break;
        case 6:
            while (query.next()) {
                auto x = new Receivable();
                x->setleaseId(query.value(0).toInt());
                x->setheadId(query.value(1).toInt());
                x->setamount(query.value(2).toInt());
                receivables.push_back(x);
            }
            break;
        case 7:
            query.first();
            maxLeaseId = query.value(0).toInt();
            break;
        }
    }
    db.close();

    foreach(auto lease, m_leases){
        for(int i = 0; i < receivables.size(); i++){
            if(receivables[i]->leaseId() == lease->id())
                lease->receivables().push_back(receivables[i]);
        }
    }
}

void MainVM::setMaxIds()
{
    maxPlotId = getMaxId(m_plots);
    maxSpaceId = getMaxId(m_spaces);
    maxTenantId = getMaxId(m_tenants);
    maxHeadId = getMaxId(m_heads);
    maxLeaseId = getMaxId(m_leases);
}

void MainVM::setSelected()
{
    setselectedPlot(0);
    setselectedTenant(0);
    setselectedControlHead(0);
    setselectedHead(0);
}

void MainVM::hookupSignalAndSlots()
{
    QObject::connect(this, &MainVM::selectedPlotChanged, this, &MainVM::onSelectedPlotChanged);
    QObject::connect(this, &MainVM::selectedControlHeadChanged, this, &MainVM::onSelectedControlHeadChanged);
}

void MainVM::onSelectedPlotChanged()
{
    if(m_plots.size() > 0){
        int plotId = m_plots[m_selectedPlot]->id();

        m_filteredSpaces.clear();       
        for(int i = 0; i < m_spaces.size(); i++){
            if(m_spaces[i]->plotId() == plotId)
                m_filteredSpaces.push_back(m_spaces[i]);
        }
        emit filteredSpacesChanged();
        setselectedSpace(0);

        m_filteredLeases.clear();
        for(int i = 0; i < m_leases.size(); i++){
            if(m_leases[i]->plotId() == plotId)
                m_filteredLeases.push_back(m_leases[i]);
        }
        emit filteredLeasesChanged();
        setselectedLease(0);
    }
}

void MainVM::onSelectedControlHeadChanged()
{
    m_filteredHeads.clear();
    int controlId = m_controlHeads[m_selectedControlHead]->id();
    foreach(auto head, m_heads){
        if(head->controlId() == controlId)
            m_filteredHeads.push_back(head);
    }
    emit filteredHeadsChanged();
    setselectedHead(0);
}

template<class T>
int MainVM::getMaxId(QVector<T> &vec)
{
    int current, max;
    max = 0;
    for(int i = 0; i < vec.size(); i++){
        current = vec[i]->id();
        if(current > max) max = current;
    }
    return  max;
}
