#ifndef LEDGERVM_H
#define LEDGERVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>
class LedgerVM : public QObject
{
    Q_OBJECT
    Property(QVector<View*>, views)
public:
    explicit LedgerVM(QObject *parent = nullptr);

signals:

};

#endif // LEDGERVM_H
