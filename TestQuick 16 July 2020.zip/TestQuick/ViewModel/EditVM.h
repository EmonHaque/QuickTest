#ifndef BVM_H
#define BVM_H

#include <QObject>
#include <QVector>
#include <Utils/Constants.h>
#include <Utils/Property.h>
#include <Model/View.h>
#include "MainVM.h"

extern MainVM *mvm;

class EditVM : public QObject
{
    Q_OBJECT
    Property(QVector<View*>, views)
    Property(Plot*, editedPlot)
    Property(Space*, editedSpace)
    Property(Tenant*, editedTenant)
    Property(Head*, editedHead)
    Property(Lease*, editedLease)
    Property(Receivable*, newReceivable)
    Property(bool, isOnEdit)
    Property(QVector<Tenant*>, filteredTenants)
    Property(int, selectedTenant)

public:
    explicit EditVM(QObject *parent = nullptr);
    Q_INVOKABLE void update();
    Q_INVOKABLE void discardUpdate();
    Q_INVOKABLE void setEdit(int index);
    Q_INVOKABLE void addReceivable();
    Q_INVOKABLE void removeReceivable(int index);
    Q_INVOKABLE QString getTenantName(int id);
    Q_INVOKABLE QString getSpaceName(int id);
    Q_INVOKABLE QString getPlotName(int id);
    Q_INVOKABLE void filterTenants(QString text);

private slots:
    void onSelectedSubViewChanged();

private:
    void hookupSignalAndSlots();
    int selectedIndex;
};

#endif // BVM_H
