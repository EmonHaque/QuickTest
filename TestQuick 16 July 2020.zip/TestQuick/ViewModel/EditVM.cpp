#include "EditVM.h"

EditVM::EditVM(QObject *parent) : QObject(parent)
{
    hookupSignalAndSlots();
    m_views.push_back(new View(PlotIcon, "Views/EditViews/PlotView.qml", SubViewType::Plot));
    m_views.push_back(new View(SpaceIcon, "Views/EditViews/SpaceView.qml", SubViewType::Space));
    m_views.push_back(new View(TenantIcon, "Views/EditViews/TenantView.qml", SubViewType::Tenant));
    m_views.push_back(new View(HeadIcon, "Views/EditViews/HeadView.qml", SubViewType::Head));
    m_views.push_back(new View(LeaseIcon, "Views/EditViews/LeaseView.qml", SubViewType::Lease));
    emit viewsChanged();

    seteditedPlot(new Plot());
    seteditedSpace(new Space());
    seteditedTenant(new Tenant());
    seteditedHead(new Head());
    seteditedLease(new Lease());
    setnewReceivable(new Receivable());
    setisOnEdit(false);
    setfilteredTenants(mvm->tenants());
}

void EditVM::update()
{
    setisOnEdit(false);
    switch (mvm->selectedSubView()) {
    case SubViewType::Plot:
        mvm->plots()[selectedIndex]->setname(editedPlot()->name());
        mvm->plots()[selectedIndex]->setdescription(editedPlot()->description());
        break;
    case SubViewType::Space:
        mvm->filteredSpaces()[selectedIndex]->setname(editedSpace()->name());
        mvm->filteredSpaces()[selectedIndex]->setdescription(editedSpace()->description());
        mvm->filteredSpaces()[selectedIndex]->setisVacant(editedSpace()->isVacant());
        break;
    case SubViewType::Tenant:
        filteredTenants()[selectedTenant()]->setname(editedTenant()->name());
        filteredTenants()[selectedTenant()]->setfather(editedTenant()->father());
        filteredTenants()[selectedTenant()]->setmother(editedTenant()->mother());
        filteredTenants()[selectedTenant()]->sethusband(editedTenant()->husband());
        filteredTenants()[selectedTenant()]->setcontactNo(editedTenant()->contactNo());
        filteredTenants()[selectedTenant()]->setaddress(editedTenant()->address());
        filteredTenants()[selectedTenant()]->setnid(editedTenant()->nid());
        filteredTenants()[selectedTenant()]->sethasLeft(editedTenant()->hasLeft());
        break;
    case SubViewType::Head:
        mvm->filteredHeads()[selectedIndex]->setname(editedHead()->name());
        mvm->filteredHeads()[selectedIndex]->setdescription(editedHead()->description());
        break;
    case SubViewType::Lease:
        mvm->filteredLeases()[selectedIndex]->setbusiness(editedLease()->business());
        mvm->filteredLeases()[selectedIndex]->setdate(editedLease()->date());
        mvm->filteredLeases()[selectedIndex]->setisExpired(editedLease()->isExpired());

        qDeleteAll(mvm->filteredLeases()[selectedIndex]->receivables());
        mvm->filteredLeases()[selectedIndex]->receivables().clear();

        foreach(auto receivable, editedLease()->receivables())
            mvm->filteredLeases()[selectedIndex]->receivables().push_back(receivable);

        emit mvm->filteredLeases()[selectedIndex]->receivablesChanged();
        editedLease()->receivables().clear();
        break;
    }
}

void EditVM::discardUpdate()
{
    setisOnEdit(false);
    if(mvm->selectedSubView() == SubViewType::Lease){
        qDeleteAll(editedLease()->receivables());
        editedLease()->receivables().clear();
    }
}

void EditVM::setEdit(int index)
{
    setisOnEdit(true);
    selectedIndex = index;

    switch (mvm->selectedSubView()) {
    case SubViewType::Plot:
        editedPlot()->setname(mvm->plots()[index]->name());
        editedPlot()->setdescription(mvm->plots()[index]->description());
        break;
    case SubViewType::Space:
        editedSpace()->setname(mvm->filteredSpaces()[index]->name());
        editedSpace()->setdescription(mvm->filteredSpaces()[index]->description());
        editedSpace()->setisVacant(mvm->filteredSpaces()[index]->isVacant());
        break;
    case SubViewType::Tenant:
        editedTenant()->setname(filteredTenants()[selectedTenant()]->name());
        editedTenant()->setfather(filteredTenants()[selectedTenant()]->father());
        editedTenant()->setmother(filteredTenants()[selectedTenant()]->mother());
        editedTenant()->sethusband(filteredTenants()[selectedTenant()]->husband());
        editedTenant()->setaddress(filteredTenants()[selectedTenant()]->address());
        editedTenant()->setnid(filteredTenants()[selectedTenant()]->nid());
        editedTenant()->setcontactNo(filteredTenants()[selectedTenant()]->contactNo());
        editedTenant()->sethasLeft(filteredTenants()[selectedTenant()]->hasLeft());
        break;
    case SubViewType::Head:
        editedHead()->setname(mvm->filteredHeads()[index]->name());
        editedHead()->setdescription(mvm->filteredHeads()[index]->description());
        break;
    case SubViewType::Lease:
        editedLease()->setid(mvm->filteredLeases()[index]->id());
        editedLease()->setbusiness(mvm->filteredLeases()[index]->business());
        editedLease()->setdate(mvm->filteredLeases()[index]->date());
        editedLease()->setisExpired(mvm->filteredLeases()[index]->isExpired());

        foreach(auto receivable, mvm->filteredLeases()[index]->receivables()){
            auto x = new Receivable();
            x->setheadId(receivable->headId());
            x->setleaseId(receivable->leaseId());
            x->setamount(receivable->amount());
            editedLease()->receivables().push_back(x);
        }
        emit editedLease()->receivablesChanged();
        break;
    }
}

void EditVM::addReceivable()
{
    newReceivable()->setheadId(mvm->receivableHeads()[mvm->selectedReceivableHead()]->id());
    newReceivable()->setleaseId(editedLease()->id());
    editedLease()->receivables().push_back(newReceivable());
    emit editedLease()->receivablesChanged();
    setnewReceivable(new Receivable());
}

void EditVM::removeReceivable(int index)
{
    delete editedLease()->receivables().takeAt(index);
    emit editedLease()->receivablesChanged();
}

QString EditVM::getTenantName(int id)
{
    foreach(auto tenant, mvm->tenants()){
        if(tenant->id() == id)
            return tenant->name() + " | " + tenant->contactNo();
    }
}

QString EditVM::getSpaceName(int id)
{
    foreach(auto space, mvm->spaces()){
        if(space->id() == id)
            return space->name();
    }
}

QString EditVM::getPlotName(int id)
{
    foreach(auto plot, mvm->plots()){
        if(plot->id() == id)
            return plot->name();
    }
}

void EditVM::filterTenants(QString text)
{
    if(text.isEmpty()) setfilteredTenants(mvm->tenants());
    else{
        m_filteredTenants.clear();
        foreach(auto tenant, mvm->tenants()){
            if(tenant->name().contains(text, Qt::CaseInsensitive))
                m_filteredTenants.push_back(tenant);
        }
        emit filteredTenantsChanged();
    }
}

void EditVM::onSelectedSubViewChanged()
{
    if(isOnEdit())
        setisOnEdit(false);
}

void EditVM::hookupSignalAndSlots()
{
    QObject::connect(mvm, &MainVM::selectedSubViewChanged, this, &EditVM::onSelectedSubViewChanged);
}

