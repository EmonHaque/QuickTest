#ifndef CONTROLHEAD_H
#define CONTROLHEAD_H
#include <QObject>
#include <Utils/Property.h>

class ControlHead: public QObject{

    Q_OBJECT
    Property(int, id)
    Property(QString, name)

};
#endif // CONTROLHEAD_H
