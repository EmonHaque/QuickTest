#ifndef VIEW_H
#define VIEW_H

#include <QObject>
#include <QString>
#include "Utils/Property.h"
#include <Model/ViewType.h>
#include <Model/SubViewType.h>

class View : public QObject{
    Q_OBJECT
    Property(QString, icon)
    Property(QString, view)
    Property(ViewType::Type, type)
    Property(SubViewType::Type, subType)

public:
   View(QString icon, QString view, ViewType::Type type = ViewType::Home): m_icon(icon), m_view(view), m_type(type) {}
   View(QString icon, QString view, SubViewType::Type subType = SubViewType::Plot): m_icon(icon), m_view(view), m_subType(subType) {}
};

#endif // VIEW_H
