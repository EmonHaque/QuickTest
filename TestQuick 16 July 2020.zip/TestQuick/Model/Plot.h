#ifndef PLOT_H
#define PLOT_H

#include <QObject>
#include <Utils/Property.h>

class Plot: public QObject{

    Q_OBJECT
    Property(int, id)
    Property(QString, name)
    Property(QString, description)
};

#endif // PLOT_H
