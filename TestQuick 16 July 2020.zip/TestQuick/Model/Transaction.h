#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <QObject>
#include <Utils/Property.h>

class Transaction: public QObject{


};

#endif // TRANSACTION_H
