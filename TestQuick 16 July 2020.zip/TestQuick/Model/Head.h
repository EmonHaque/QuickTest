#ifndef HEAD_H
#define HEAD_H

#include <QObject>
#include <Utils/Property.h>

class Head: public QObject{

    Q_OBJECT
    Property(int, id)
    Property(int, controlId)
    Property(QString, name)
    Property(QString, description)

};
#endif // HEAD_H
