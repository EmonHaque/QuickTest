#ifndef SPACE_H
#define SPACE_H

#include <QObject>
#include <Utils/Property.h>

class Space: public QObject{

    Q_OBJECT
    Property(int, id)
    Property(int, plotId)
    Property(QString, name)
    Property(QString, description)
    Property(bool, isVacant)
};
#endif // SPACE_H
