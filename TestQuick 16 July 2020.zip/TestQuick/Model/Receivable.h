#ifndef RECEIVABLE_H
#define RECEIVABLE_H

#include <QObject>
#include <Utils/Property.h>

class Receivable: public QObject{

    Q_OBJECT
    Property(int, leaseId)
    Property(int, headId)
    Property(int, amount)
};

#endif // RECEIVABLE_H
