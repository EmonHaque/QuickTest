#ifndef LEASE_H
#define LEASE_H

#include <QObject>
#include <QDate>
#include <QVector>
#include <Utils/Property.h>
#include "Receivable.h"

class Lease: public QObject{

    Q_OBJECT
    Property(int, id)
    Property(int, plotId)
    Property(int, spaceId)
    Property(int, tenantId)
    Property(QDate, date)
    Property(QString, business)
    Property(bool, isExpired)
    Property(QVector<Receivable*>, receivables);
};
#endif // LEASE_H
