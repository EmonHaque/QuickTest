#ifndef VIEWTYPE_H
#define VIEWTYPE_H

#include <QObject>

class ViewType : public QObject{

    Q_OBJECT
    Q_ENUMS(Type)
    Q_PROPERTY(Type type READ type CONSTANT)

public:
    enum Type{Home, Add, Edit, Transact, Ledger};
    Type type(){ return m_type; }

private:
    Type m_type;
};

#endif // VIEWTYPE_H
