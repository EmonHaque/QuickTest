#ifndef SUBVIEWTYPE_H
#define SUBVIEWTYPE_H

#include <QObject>

class SubViewType : public QObject{

    Q_OBJECT
    Q_ENUMS(Type)
    Q_PROPERTY(Type type READ type CONSTANT)

public:
    enum Type{Plot, Space, Tenant, Lease, Head };
    Type type(){ return m_subtype; }

private:
    Type m_subtype;
};

#endif // SUBVIEWTYPE_H
