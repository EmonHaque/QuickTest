#ifndef TENANT_H
#define TENANT_H

#include <QObject>
#include <Utils/Property.h>

class Tenant: public QObject{

    Q_OBJECT
    Property(int, id)
    Property(QString, name)
    Property(QString, father)
    Property(QString, mother)
    Property(QString, husband)
    Property(QString, address)
    Property(QString, nid)
    Property(QString, contactNo)
    Property(bool, hasLeft)

};
#endif // TENANT_H
