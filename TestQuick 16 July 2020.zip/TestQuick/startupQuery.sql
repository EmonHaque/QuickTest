SELECT * FROM Plots ORDER BY Name;
SELECT * FROM Spaces ORDER BY PlotId, Name;
SELECT * FROM ControlHeads ORDER BY Name;
SELECT * FROM Heads ORDER BY ControlId, Name;
SELECT * FROM Tenants ORDER BY Name;
SELECT * FROM Leases WHERE IsExpired = 0 ORDER BY PlotId, SpaceId;
SELECT * FROM Receivables;
SELECT MAX(Id) FROM Leases
